package com.demo;

public class TestExpressFunction {
	public String test() {
		return "TestExpressFunction";
	}
}

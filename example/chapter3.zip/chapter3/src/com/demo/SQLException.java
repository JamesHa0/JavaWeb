package com.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SQLException extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub

		Connection dbconn = null;
		try {
			dbconn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/wenote?autoReconnect=true&serverTimezone=Asia/Shanghai&characterEncoding=UTF-8",
					"root", "19940311admin");
		} catch (java.sql.SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		;

		String category = req.getParameter("category");
		ArrayList<Product> productList = new ArrayList<Product>();
		try {
			String sql = "select * from products where category=?";
			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setString(1, category);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				Product product = new Product();
				product.setId(result.getString("id"));
				product.setName(result.getString("name"));
				product.setPrice(result.getDouble("price"));
				product.setStock(result.getInt("stock"));
				productList.add(product);
			}
			if (!productList.isEmpty()) {
				req.getSession().setAttribute("productList", productList);
				resp.sendRedirect("/hellowen/displayAllProduct.jsp");
			} else {
				resp.sendRedirect("/helloweb/error.jsp");
			}
		} catch (Exception e) {
			// TODO: handle exception
			resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "产生数据库连接错误，请联系管理员");
		}
	}

	
}

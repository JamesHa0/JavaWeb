package com.demo;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(name = "LoginServlet", urlPatterns = { "/user-login" })
public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		
		String username = req.getParameter("username");
		String password = req.getParameter("password");

		PrintWriter out = resp.getWriter();
		out.println("<!DOCTYPE html>");
		out.println("<html><body>");

		if ("admin".equals(username) && "admin".equals(password)) {
			out.println("登录成功！欢迎您， " + username);
		} else {
			out.println("对不起！您的用户名或密码不正确．");
		}

		out.println("</body></html>");
	}
}

/*
 * if ("admin".equals(username) && "admin".equals(password)) {
 * req.setAttribute("username", username); RequestDispatcher rd =
 * req.getRequestDispatcher("/welcome.jsp"); rd.forward(req, resp);
 * out.println("登录成功！欢迎您， " + username); } else { RequestDispatcher rd =
 * req.getRequestDispatcher("/login.html"); rd.forward(req, resp);
 * out.println("对不起！您的用户名或密码不正确．"); }
 */
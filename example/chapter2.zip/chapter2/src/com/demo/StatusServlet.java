package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/StatusServlet" })
public class StatusServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		String qq = req.getParameter("q");
		if (qq == null) {
			out.println("没有提供请求参数");
		} else if (qq.equals("0")) {
			out.println(resp.getStatus() + "<br>");
			out.println("Hello");
		} else if (qq.equals("1")) {
			resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
		} else if (qq.equals("2")) {
			resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		} else {
			resp.sendError(404, "resource cannot founded");
		}

		/*
		 * sendError(int sc, String
		 * msg)，如果在web.xml有定义对应的错误码页面就会跳到该页面，如果没有就返回tomcat自己的页面，并且显示msg的内容。
		 * setStatus，只是修改了响应码而已，数据还是正常返回。
		 */
	}
}

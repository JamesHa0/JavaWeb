package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SendRedirect", urlPatterns = { "/redirect.do" })
public class RedirectServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userAgent = req.getHeader("User-Agent"); // 获取请求头
		req.setAttribute("param1", "请求作用于属性");
		req.getSession().setAttribute("param2", "会话作用域属性");

		// 根据请求头的值将浏览器重定向到不同的URL
		if ((userAgent != null) && (userAgent.indexOf("MSIE") != -1)) { // MSIE：IE浏览器
			resp.sendRedirect("welcome.jsp");
		} else {
			resp.sendRedirect("http://localhost:8080/");
		}

	}
}

package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name="ExcelServlet",urlPatterns= {"/excel.xlsx"})

public class ExcelServlet extends HttpServlet{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setHeader("Cache-Control","no-cache");
		resp.setContentType("application/vnd.ms-excel;charset=gb2312");
		PrintWriter out=resp.getWriter();
		out.println("<h3>Student information</h3>");
		out.println("学号\t姓名\t性别\t年龄\t所在系");
		out.println("955001\t李勇\t男\t20\t信息");
		out.println("95002\t刘晨\t女\t19\t数学");
	}
}
